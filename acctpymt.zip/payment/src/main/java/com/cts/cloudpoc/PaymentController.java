package com.cts.cloudpoc;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
@RequestMapping(path="/payment")
public class PaymentController {
	
	@Autowired
	PaymentRepository paymentRepository;
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@PostMapping(path="/add")
	@ResponseBody
	public String add(@RequestBody Payment payment) {
		List<ServiceInstance> instances = discoveryClient.getInstances("account");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		baseUrl = baseUrl +"/account/number";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response=null;
		Map<String, Object> params = new HashMap<>();
		params.put("accountNumber", payment.getAccountNumber());
		params.put("ifscCode", payment.getIfscCode());
		try{
		response=restTemplate.exchange(baseUrl,
				HttpMethod.GET, getHeaders(),String.class,params);
		}catch (Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println(response.getBody());
		Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        String transactionRef = cal.getWeekYear() + "" + String.format("%15s", cal.getTimeInMillis()+"").replace(' ', '0');
        payment.setTransactionRef(transactionRef);
		//paymentRepository.save(payment);
		return "saved";
	}
	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
	@GetMapping(path="/account")
	@ResponseBody
	public List<Payment> getPaymentsByAcctNo(@RequestParam Long accountNumber, @RequestParam String ifscCode,
			@RequestParam String from, @RequestParam String to){
		SimpleDateFormat sd= new SimpleDateFormat("dd-MMM-yyyy");
		System.out.println("from "+from);
		System.out.println("to "+to);
		
		Date fromDate =null;
		Date toDate = null;
		try {
			fromDate = sd.parse(from);
			toDate = sd.parse(to);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("from Date"+fromDate);
		System.out.println("to Date"+toDate);
		
		return paymentRepository.findByAccountNumberAndIfscCodeAndDateOfTransactionBetween(accountNumber, ifscCode, fromDate, toDate);
	}
	
	@GetMapping(path="/all")
	@ResponseBody
	public Iterable<Payment> findAll(){
		return paymentRepository.findAll();
	}

}
