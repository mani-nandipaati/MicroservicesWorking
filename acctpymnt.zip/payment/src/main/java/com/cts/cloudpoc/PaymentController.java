package com.cts.cloudpoc;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Controller
@RequestMapping(path="/payment")
public class PaymentController {
	
	@Autowired
	PaymentRepository paymentRepository;
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@Autowired
	RestTemplate restTemplate;
	
	@PostMapping(path="/add")
	@ResponseBody
	public String add(@RequestBody Payment payment) {
		List<ServiceInstance> instances = discoveryClient.getInstances("account");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		System.out.println("baseUrl-->"+baseUrl);
		System.out.println(payment.getAccountNumber());
		System.out.println(payment.getIfscCode());
		Account account = null;
		try{
			baseUrl = baseUrl +"/account/number";
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseUrl).queryParam("accountNumber", payment.getAccountNumber()).
			queryParam("ifscCode", payment.getIfscCode());;
			account=restTemplate.getForObject(builder.toUriString(), Account.class);
		}catch (Exception ex)
		{
			ex.printStackTrace();
		}
		System.out.println(account);
		Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        String transactionRef = cal.getWeekYear() + "" + String.format("%15s", cal.getTimeInMillis()+"").replace(' ', '0');
        payment.setTransactionRef(transactionRef);
		//paymentRepository.save(payment);
		return "saved";
	}
	
	
	@GetMapping(path="/account")
	@ResponseBody
	public List<Payment> getPaymentsByAcctNo(@RequestParam Long accountNumber, @RequestParam String ifscCode,
			@RequestParam String from, @RequestParam String to){
		SimpleDateFormat sd= new SimpleDateFormat("dd-MMM-yyyy");
		System.out.println("from "+from);
		System.out.println("to "+to);
		
		Date fromDate =null;
		Date toDate = null;
		try {
			fromDate = sd.parse(from);
			toDate = sd.parse(to);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("from Date"+fromDate);
		System.out.println("to Date"+toDate);
		
		return paymentRepository.findByAccountNumberAndIfscCodeAndDateOfTransactionBetween(accountNumber, ifscCode, fromDate, toDate);
	}
	
	@GetMapping(path="/all")
	@ResponseBody
	public Iterable<Payment> findAll(){
		return paymentRepository.findAll();
	}

}
