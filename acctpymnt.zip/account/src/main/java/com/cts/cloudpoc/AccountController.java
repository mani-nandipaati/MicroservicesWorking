package com.cts.cloudpoc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/account")
public class AccountController {

	@Autowired
	AccountRepository accountRepository;
	
	@PostMapping(path="/add",consumes="application/json")
	@ResponseBody
	public String addAccounts(@RequestBody Account account) {
		accountRepository.save(account);
		return "saved";
	}
	
	@GetMapping(path="/all")
	@ResponseBody
	public Iterable<Account> getAll() {
		return accountRepository.findAll();
	}
	
	@GetMapping(path="/number")
	@ResponseBody
	public Account findByAccountNumber(@RequestParam Long accountNumber, 
			@RequestParam String ifscCode) {
		System.out.println("inside findByAccountNumber");
		Account account = accountRepository.findByAccountNumberAndIfscCode(accountNumber, ifscCode);
		System.out.println(account);
		return account;
	}
	
	@GetMapping(path="/customer")
	@ResponseBody
	public Account findByCusomerId(@RequestParam Integer customerId) {
		return accountRepository.findByCustomerId(customerId);
	}
	
	@GetMapping(path="/test")
	@ResponseBody
	public String testMethod() {
		return "From Account";
	}
}
