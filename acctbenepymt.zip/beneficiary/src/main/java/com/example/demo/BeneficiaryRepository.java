package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface BeneficiaryRepository extends CrudRepository<Beneficiary, Long>{
	Beneficiary findByCustomerId(Integer customerId);
}
