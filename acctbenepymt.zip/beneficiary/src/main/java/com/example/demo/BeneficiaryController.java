package com.example.demo;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/bene")
public class BeneficiaryController {
	
	@Autowired
	BeneficiaryRepository beneficiaryRepository;
	
	@PostMapping(path="/add",consumes="application/json")
	@ResponseBody
	public String addBeneficiary(@RequestBody Beneficiary beneficiary) {
		try {
			beneficiaryRepository.save(beneficiary);
		}
		catch(Exception e) {
			e.printStackTrace();
			return "FAIL";
		}
		return "SUCCESS";
	}
	
	@GetMapping(path="/customer")
	@ResponseBody
	public Beneficiary findByCusomerId(@RequestParam Integer customerId) {
		Beneficiary beneficiary = null;
		try {
			beneficiary = beneficiaryRepository.findByCustomerId(customerId);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return beneficiary;
	}
	
	@GetMapping(path="/all")
	@ResponseBody
	public Iterable<Beneficiary> findAll() {
		Iterable<Beneficiary> all = Collections.EMPTY_LIST;
		try {
			all = beneficiaryRepository.findAll();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return all;
	}
	
	@GetMapping(path="/delete")
	@ResponseBody
	public String delete() {
		try {
			beneficiaryRepository.deleteAll();
		}
		catch(Exception e) {
			e.printStackTrace();
			return "FAIL";
		}
		return "SUCCESS";
	}


}
