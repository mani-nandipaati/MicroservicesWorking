package com.cts.cloudpoc;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Controller
@RequestMapping(path="/payment")
public class PaymentController {

	@Autowired
	PaymentRepository paymentRepository;

	@Autowired
	private DiscoveryClient discoveryClient;

	@Autowired
	RestTemplate restTemplate;

	@PostMapping(path="/add")
	@ResponseBody
	public String add(@RequestBody Payment payment) {
		try{
			paymentRepository.save(payment);
		}
		catch(Exception e) {
			return "FAIL";
		}
		return "SUCCESS";
	}

	@PostMapping(path="/transfer")
	@ResponseBody
	public String transfer(@RequestParam Long drAccountNumber, @RequestParam Long crAccountNumber,
			@RequestParam String drIfscCode, @RequestParam String crIfscCode, @RequestParam Double amount) {
		List<ServiceInstance> instances = discoveryClient.getInstances("account");
		ServiceInstance serviceInstance = instances.get(0);
		String baseUrl = serviceInstance.getUri().toString();
		try{
			String acctNumberUrl = baseUrl +"/account/number";
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(acctNumberUrl).
					queryParam("accountNumber", drAccountNumber).
					queryParam("ifscCode", drIfscCode);
			Account drAccount=restTemplate.getForObject(builder.toUriString(), Account.class);
			if(drAccount == null) {
				return "FAIL";
			}
			if(drAccount.getBalance() < amount) {
				return "FAIL";
			}
			builder = UriComponentsBuilder.fromUriString(acctNumberUrl).
					queryParam("accountNumber", crAccountNumber).
					queryParam("ifscCode", crIfscCode);
			Account crAccount=restTemplate.getForObject(builder.toUriString(), Account.class);
			if(crAccount == null) {
				return "FAIL";
			}
			drAccount.setBalance(drAccount.getBalance()-amount);
			crAccount.setBalance(crAccount.getBalance()+amount);
			String status = restTemplate.postForObject(baseUrl+"/account/add", drAccount, String.class);
			if("FAIL".equals(status)) {
				return status;
			}
			status = restTemplate.postForObject(baseUrl+"/account/add", crAccount, String.class);
			if("FAIL".equals(status)) {
				return status;
			}
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			String transactionRef = cal.getWeekYear() + "" + String.format("%15s", cal.getTimeInMillis()+"").replace(' ', '0');
			Date d = cal.getTime();
			Payment payment = new Payment();
			payment.setAccountNumber(drAccountNumber);
			payment.setAmount(amount);
			payment.setDateOfTransaction(d);
			payment.setDebitOrCredit("DR");
			payment.setIfscCode(drIfscCode);
			payment.setStatus("COMPLETED");
			payment.setTransactionRef(transactionRef);
			status = add(payment);
			if("FAIL".equals(status)) {
				return status;
			}
			payment = new Payment();
			payment.setAccountNumber(crAccountNumber);
			payment.setAmount(amount);
			payment.setDateOfTransaction(d);
			payment.setDebitOrCredit("CR");
			payment.setIfscCode(crIfscCode);
			payment.setStatus("COMPLETED");
			payment.setTransactionRef(transactionRef);
			status = add(payment);
			if("FAIL".equals(status)) {
				return status;
			}

		}catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return "SUCCESS";
	}


	@GetMapping(path="/transactions")
	@ResponseBody
	public List<Payment> getPaymentsByAcctNo(@RequestParam Long accountNumber, @RequestParam String ifscCode,
			@RequestParam String from, @RequestParam String to){
		SimpleDateFormat sd= new SimpleDateFormat("dd-MMM-yyyy");
		System.out.println("from "+from);
		System.out.println("to "+to);

		Date fromDate =null;
		Date toDate = null;
		try {
			fromDate = sd.parse(from);
			toDate = sd.parse(to);
		}
		catch(Exception e) {
			System.out.println(e);
		}

		System.out.println("from Date"+fromDate);
		System.out.println("to Date"+toDate);

		return paymentRepository.findByAccountNumberAndIfscCodeAndDateOfTransactionBetween(accountNumber, ifscCode, fromDate, toDate);
	}

	@GetMapping(path="/all")
	@ResponseBody
	public Iterable<Payment> findAll(){
		return paymentRepository.findAll();
	}
	
	@GetMapping(path="/delete")
	@ResponseBody
	public String delete() {
		try {
			paymentRepository.deleteAll();
		}
		catch(Exception e) {
			return "FAIL";
		}
		return "SUCCESS";
	}

}
